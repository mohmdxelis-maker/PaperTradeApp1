package com.papertrade.app.ui

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.papertrade.app.model.Trade
import com.papertrade.app.model.TradeDirection
import com.papertrade.app.viewmodel.TradeViewModel
import kotlinx.coroutines.delay

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TradingScreen(vm: TradeViewModel) {
    if (!vm.sessionActive) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("الرجاء ضبط الإعدادات أولاً من تبويب Setup", style = MaterialTheme.typography.bodyLarge)
        }
        return
    }

    var priceText by remember { mutableStateOf("") }
    var showCloseDialog by remember { mutableStateOf<Long?>(null) }
    val webViewRef = remember { mutableStateOf<WebView?>(null) }
    var pageLoaded by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.loadWithOverviewMode = true
                        settings.useWideViewPort = true
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView, url: String) {
                                pageLoaded = true
                            }
                        }
                        webChromeClient = WebChromeClient()
                        loadUrl("file:///android_asset/tradingview.html")
                    }.also { webViewRef.value = it }
                },
                update = {}
            )
        }

        LaunchedEffect(pageLoaded, vm.settings.symbol, vm.settings.selectedIndicator) {
            if (pageLoaded) {
                delay(200)
                webViewRef.value?.evaluateJavascript(
                    "initChart('${vm.settings.symbol}', ['${vm.settings.selectedIndicator.studyParam}'])",
                    null
                )
            }
        }

        Card(Modifier.fillMaxWidth().padding(8.dp)) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("السعر الحالي") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = {
                        priceText.toDoubleOrNull()?.let { vm.updatePrice(it) }
                    }) { Text("تحديث") }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            vm.updatePrice(priceText.toDoubleOrNull() ?: return@Button)
                            vm.openTrade(TradeDirection.BUY)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text("شراء BUY", fontWeight = FontWeight.Bold) }

                    Button(
                        onClick = {
                            vm.updatePrice(priceText.toDoubleOrNull() ?: return@Button)
                            vm.openTrade(TradeDirection.SELL)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) { Text("بيع SELL", fontWeight = FontWeight.Bold) }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Text("الرصيد: $${String.format("%.2f", vm.balance)}", fontWeight = FontWeight.SemiBold)
                    Text("الحصة: $${String.format("%.2f", vm.equity)}", fontWeight = FontWeight.SemiBold)
                }
            }
        }

        if (vm.openTrades.isNotEmpty()) {
            Text("الصفقات المفتوحة", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(horizontal = 12.dp))
            LazyColumn(Modifier.height(130.dp)) {
                items(vm.openTrades.toList(), key = { it.id }) { trade ->
                    TradeRow(trade, onClose = { showCloseDialog = trade.id })
                }
            }
        }
    }

    showCloseDialog?.let { tradeId ->
        val trade = vm.openTrades.find { it.id == tradeId }
        if (trade != null) {
            AlertDialog(
                onDismissRequest = { showCloseDialog = null },
                title = { Text("إغلاق الصفقة") },
                text = {
                    val exitPrice = priceText.toDoubleOrNull() ?: vm.currentPrice
                    val pnl = (if (trade.direction == TradeDirection.BUY) exitPrice - trade.entryPrice else trade.entryPrice - exitPrice) * trade.quantity
                    Text("سعر الدخول: ${trade.entryPrice}\nالكمية: ${String.format("%.4f", trade.quantity)}\nالربح/الخسارة المتوقعة: $${String.format("%.2f", pnl)}\n\nتأكيد الإغلاق؟")
                },
                confirmButton = {
                    TextButton(onClick = {
                        vm.closeTrade(tradeId, priceText.toDoubleOrNull() ?: vm.currentPrice)
                        showCloseDialog = null
                    }) { Text("إغلاق") }
                },
                dismissButton = {
                    TextButton(onClick = { showCloseDialog = null }) { Text("إلغاء") }
                }
            )
        }
    }
}

@Composable
private fun TradeRow(trade: Trade, onClose: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${trade.direction.name} | ${trade.symbol}", fontWeight = FontWeight.Bold)
                Text("دخول: ${trade.entryPrice} | SL: ${trade.stopLoss?.let { String.format("%.2f", it) } ?: "-"} | TP: ${trade.takeProfit?.let { String.format("%.2f", it) } ?: "-"}")
            }
            FilledTonalButton(onClick = onClose, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                Text("إغلاق")
            }
        }
    }
}
