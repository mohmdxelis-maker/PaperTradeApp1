package com.papertrade.app.model

data class Indicator(
    val id: String,
    val name: String,
    val studyParam: String
)

data class Trade(
    val id: Long,
    val symbol: String,
    val direction: TradeDirection,
    val entryPrice: Double,
    val exitPrice: Double? = null,
    val quantity: Double,
    val stopLoss: Double? = null,
    val takeProfit: Double? = null,
    val entryTime: Long,
    val exitTime: Long? = null,
    val pnl: Double? = null,
    val status: TradeStatus = TradeStatus.OPEN
)

enum class TradeDirection { BUY, SELL }

enum class TradeStatus { OPEN, WIN, LOSS }

data class AppSettings(
    val selectedIndicator: Indicator = indicators[0],
    val initialBalance: Double = 10000.0,
    val riskPercent: Double = 1.0,
    val riskReward: Double = 2.0,
    val moveSLToBreakeven: Boolean = false,
    val symbol: String = "BINANCE:BTCUSDT"
)

val indicators = listOf(
    Indicator("rsi", "RSI", "RSI@tv-basicstudies"),
    Indicator("macd", "MACD", "MACD@tv-basicstudies"),
    Indicator("ma", "Moving Average", "MA@tv-basicstudies"),
    Indicator("bb", "Bollinger Bands", "BB@tv-basicstudies"),
    Indicator("stoch", "Stochastic", "Stochastic@tv-basicstudies"),
    Indicator("ema", "EMA", "EMA@tv-basicstudies"),
    Indicator("ichimoku", "Ichimoku Cloud", "Ichimoku@tv-basicstudies"),
    Indicator("sar", "Parabolic SAR", "SAR@tv-basicstudies")
)
