package com.papertrade.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.papertrade.app.model.AppSettings
import com.papertrade.app.model.indicators
import com.papertrade.app.viewmodel.TradeViewModel

@Composable
fun SetupScreen(vm: TradeViewModel) {
    val scroll = rememberScrollState()
    var selectedIndicator by remember { mutableStateOf(vm.settings.selectedIndicator) }
    var balanceText by remember { mutableStateOf(vm.settings.initialBalance.toLong().toString()) }
    var riskText by remember { mutableStateOf(vm.settings.riskPercent.toString()) }
    var rrText by remember { mutableStateOf(vm.settings.riskReward.toString()) }
    var moveSL by remember { mutableStateOf(vm.settings.moveSLToBreakeven) }
    var symbolText by remember { mutableStateOf(vm.settings.symbol) }
    var indicatorExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("إعدادات التطبيق", style = MaterialTheme.typography.headlineSmall)

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("المؤشر", style = MaterialTheme.typography.titleMedium)
                ExposedDropdownMenuBox(expanded = indicatorExpanded, onExpandedChange = { indicatorExpanded = it }) {
                    OutlinedTextField(
                        value = selectedIndicator.name,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = indicatorExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = indicatorExpanded, onDismissRequest = { indicatorExpanded = false }) {
                        indicators.forEach { ind ->
                            DropdownMenuItem(
                                text = { Text(ind.name) },
                                onClick = { selectedIndicator = ind; indicatorExpanded = false }
                            )
                        }
                    }
                }
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("رأس المال", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = balanceText,
                    onValueChange = { balanceText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("الرصيد الافتراضي ($)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("إدارة المخاطر", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = riskText,
                    onValueChange = { riskText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("نسبة المخاطرة (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = rrText,
                    onValueChange = { rrText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("نسبة الربح إلى الخسارة (R:R)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = moveSL, onCheckedChange = { moveSL = it })
                    Text("نقل الستوب لوس إلى سعر الدخول عند تحقيق ربح")
                }
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("الرمز", style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = symbolText,
                    onValueChange = { symbolText = it },
                    label = { Text("مثال: BINANCE:BTCUSDT, OANDA:EURUSD") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {
                val settings = AppSettings(
                    selectedIndicator = selectedIndicator,
                    initialBalance = balanceText.toDoubleOrNull() ?: 10000.0,
                    riskPercent = riskText.toDoubleOrNull() ?: 1.0,
                    riskReward = rrText.toDoubleOrNull() ?: 2.0,
                    moveSLToBreakeven = moveSL,
                    symbol = symbolText.ifBlank { "BINANCE:BTCUSDT" }
                )
                vm.applySettings(settings)
            },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text("بدء التداول التجريبي")
        }

        if (vm.sessionActive) {
            OutlinedButton(
                onClick = { vm.resetSession() },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Text("إعادة تعيين الجلسة")
            }
        }
    }
}
