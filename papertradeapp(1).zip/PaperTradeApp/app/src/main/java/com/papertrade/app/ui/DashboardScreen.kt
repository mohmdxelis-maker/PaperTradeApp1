package com.papertrade.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.papertrade.app.model.Trade
import com.papertrade.app.model.TradeStatus
import com.papertrade.app.viewmodel.TradeViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(vm: TradeViewModel) {
    if (!vm.sessionActive) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("لا توجد بيانات. ابدأ جلسة تداول أولاً.", style = MaterialTheme.typography.bodyLarge)
        }
        return
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("الإحصائيات", style = MaterialTheme.typography.headlineSmall)
        }

        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("الرصيد", fontWeight = FontWeight.Bold)
                        Text(
                            "$${String.format("%.2f", vm.balance)}",
                            color = if (vm.balance >= vm.settings.initialBalance) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("إجمالي الربح/الخسارة", fontWeight = FontWeight.Bold)
                        val pnl = vm.totalPnl()
                        Text(
                            "$${String.format("%.2f", pnl)}",
                            color = if (pnl >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("عدد الصفقات", fontWeight = FontWeight.Bold)
                        Text("${vm.totalTrades()}")
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("نسبة النجاح", fontWeight = FontWeight.Bold)
                        Text("${String.format("%.1f", vm.winRate())}%")
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("الصفقات المفتوحة", fontWeight = FontWeight.Bold)
                        Text("${vm.openTrades.size}")
                    }
                }
            }
        }

        if (vm.closedTrades.isNotEmpty()) {
            item { Text("سجل الصفقات", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp)) }
            items(vm.closedTrades.toList().reversed(), key = { it.id }) { trade ->
                ClosedTradeCard(trade)
            }
        }
    }
}

@Composable
private fun ClosedTradeCard(trade: Trade) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${trade.direction.name} | ${trade.symbol}", fontWeight = FontWeight.Bold)
                Text(
                    "$${String.format("%.2f", trade.pnl ?: 0.0)}",
                    color = if ((trade.pnl ?: 0.0) >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Bold
                )
            }
            Text("دخول: ${trade.entryPrice} | خروج: ${trade.exitPrice?.let { String.format("%.2f", it) } ?: "-"}")
            Text("الكمية: ${String.format("%.4f", trade.quantity)}")
            Text(dateFormat.format(Date(trade.entryTime)), style = MaterialTheme.typography.bodySmall)
        }
    }
}
