package com.papertrade.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.papertrade.app.viewmodel.TradeViewModel

enum class Tab { SETUP, TRADING, DASHBOARD }

@Composable
fun App(vm: TradeViewModel) {
    var selectedTab by remember { mutableStateOf(Tab.SETUP) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == Tab.SETUP,
                    onClick = { selectedTab = Tab.SETUP },
                    icon = { Icon(Icons.Default.Settings, null) },
                    label = { Text("Setup") }
                )
                NavigationBarItem(
                    selected = selectedTab == Tab.TRADING,
                    onClick = { selectedTab = Tab.TRADING },
                    icon = { Icon(Icons.Default.ShowChart, null) },
                    label = { Text("Trade") }
                )
                NavigationBarItem(
                    selected = selectedTab == Tab.DASHBOARD,
                    onClick = { selectedTab = Tab.DASHBOARD },
                    icon = { Icon(Icons.Default.BarChart, null) },
                    label = { Text("Stats") }
                )
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (selectedTab) {
                Tab.SETUP -> SetupScreen(vm)
                Tab.TRADING -> TradingScreen(vm)
                Tab.DASHBOARD -> DashboardScreen(vm)
            }
        }
    }
}
