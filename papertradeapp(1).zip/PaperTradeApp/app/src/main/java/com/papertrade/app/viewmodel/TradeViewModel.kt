package com.papertrade.app.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.papertrade.app.model.*

class TradeViewModel : ViewModel() {

    var settings by mutableStateOf(AppSettings())
    var balance by mutableDoubleStateOf(10000.0)
    var equity by mutableDoubleStateOf(10000.0)
    var currentPrice by mutableDoubleStateOf(0.0)
    var sessionActive by mutableStateOf(false)

    val openTrades = mutableStateListOf<Trade>()
    val closedTrades = mutableStateListOf<Trade>()

    private var nextId = 1L

    fun applySettings(newSettings: AppSettings) {
        settings = newSettings
        balance = newSettings.initialBalance
        equity = balance
        sessionActive = true
    }

    fun resetSession() {
        balance = settings.initialBalance
        equity = balance
        currentPrice = 0.0
        openTrades.clear()
        closedTrades.clear()
        sessionActive = false
    }

    fun openTrade(direction: TradeDirection) {
        if (currentPrice <= 0) return
        val riskAmount = balance * (settings.riskPercent / 100.0)
        val slDistance = currentPrice * 0.01
        val sl = if (direction == TradeDirection.BUY) currentPrice - slDistance else currentPrice + slDistance
        val tp = if (direction == TradeDirection.BUY) currentPrice + slDistance * settings.riskReward else currentPrice - slDistance * settings.riskReward
        val quantity = if (slDistance > 0) riskAmount / slDistance else 1.0

        val trade = Trade(
            id = nextId++,
            symbol = settings.symbol,
            direction = direction,
            entryPrice = currentPrice,
            quantity = quantity,
            stopLoss = sl,
            takeProfit = tp,
            entryTime = System.currentTimeMillis()
        )
        openTrades.add(trade)
    }

    fun closeTrade(tradeId: Long, price: Double = currentPrice) {
        val idx = openTrades.indexOfFirst { it.id == tradeId }
        if (idx == -1) return
        val trade = openTrades[idx]
        val pnl = calcPnl(trade, price)
        balance += pnl
        val status = if (pnl >= 0) TradeStatus.WIN else TradeStatus.LOSS
        openTrades.removeAt(idx)
        closedTrades.add(trade.copy(exitPrice = price, exitTime = System.currentTimeMillis(), pnl = pnl, status = status))
        updateEquity()
    }

    fun closeAllTrades(price: Double = currentPrice) {
        openTrades.toList().forEach { closeTrade(it.id, price) }
    }

    private fun calcPnl(trade: Trade, exit: Double): Double {
        val diff = if (trade.direction == TradeDirection.BUY) exit - trade.entryPrice else trade.entryPrice - exit
        return diff * trade.quantity
    }

    fun updateEquity() {
        var unrealized = 0.0
        for (t in openTrades) {
            val diff = if (t.direction == TradeDirection.BUY) currentPrice - t.entryPrice else t.entryPrice - currentPrice
            unrealized += diff * t.quantity
        }
        equity = balance + unrealized
    }

    fun updatePrice(price: Double) {
        currentPrice = price
        updateEquity()
    }

    fun totalTrades() = closedTrades.size

    fun winRate(): Double {
        if (closedTrades.isEmpty()) return 0.0
        return closedTrades.count { it.status == TradeStatus.WIN }.toDouble() / closedTrades.size * 100.0
    }

    fun totalPnl(): Double = closedTrades.sumOf { it.pnl ?: 0.0 }
}
